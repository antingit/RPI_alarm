#!/usr/bin/python

import datetime
import cgi
import cgitb
import os

cgitb.enable()

user_ip = cgi.escape(os.environ["REMOTE_ADDR"])
user_ip = str(user_ip)

time=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
time="Last updated: "+time+" "+"connected from:"+" "+user_ip

#########################  get jpg files

f1=""
f2=""
f3=""
f4=""
f5=""
f6=""
f7=""
f8=""
f9=""
f10=""
f11=""
f12=""

path="images/"

files=sorted(os.listdir(path), key=lambda x: os.path.getctime(path+x))
fc=len(files)

try:
  fc=fc-1
  f1=files[fc]
  f2=files[fc-1]
  f3=files[fc-2]
  f4=files[fc-3]
  f5=files[fc-4]
  f6=files[fc-5]
  f7=files[fc-6]
  f8=files[fc-7]
  f9=files[fc-8]
  f10=files[fc-9]
  f11=files[fc-10]
  f12=files[fc-11]
except:
  pass

command="cp"+" "+path+f1+" "+"sorted/file1.jpg"
os.system(command)
command="cp"+" "+path+f2+" "+"sorted/file2.jpg"
os.system(command)
command="cp"+" "+path+f3+" "+"sorted/file3.jpg"
os.system(command)
command="cp"+" "+path+f4+" "+"sorted/file4.jpg"
os.system(command)
command="cp"+" "+path+f5+" "+"sorted/file5.jpg"
os.system(command)
command="cp"+" "+path+f6+" "+"sorted/file6.jpg"
os.system(command)
command="cp"+" "+path+f7+" "+"sorted/file7.jpg"
os.system(command)
command="cp"+" "+path+f8+" "+"sorted/file8.jpg"
os.system(command)
command="cp"+" "+path+f9+" "+"sorted/file9.jpg"
os.system(command)
command="cp"+" "+path+f10+" "+"sorted/file10.jpg"
os.system(command)
command="cp"+" "+path+f11+" "+"sorted/file11.jpg"
os.system(command)
command="cp"+" "+path+f12+" "+"sorted/file12.jpg"
os.system(command)

#########################  get log records

log1=""
log2=""
log3=""
log4=""
log5=""
log6=""
log7=""
log8=""
log9=""
log10=""
log11=""
log12=""
log13=""
log14=""
log15=""

try:
  logs=open("logs/rpialarm.log","r")
  logs=logs.readlines()
  fc=len(logs)
except:
  pass

try:
  fc=fc-1
  log1=">"+logs[fc]
  log2=">"+logs[fc-1]
  log3=">"+logs[fc-2]
  log4=">"+logs[fc-3]
  log5=">"+logs[fc-4]
  log6=">"+logs[fc-5]
  log7=">"+logs[fc-6]
  log8=">"+logs[fc-7]
  log9=">"+logs[fc-8]
  log10=">"+logs[fc-9]
  log11=">"+logs[fc-10]
  log12=">"+logs[fc-11]
  log13=">"+logs[fc-12]
  log14=">"+logs[fc-13]
  log15=">"+logs[fc-14]
except:
  pass

#########################

print"<!DOCTYPE html>"
print"<HTML>"
print"<meta name='viewport' content='width=device-width, initial-scale=1'>"
print"<HEAD>"
print"<TITLE> RPIalarm system web colntrol  </TITLE>"
print"</HEAD>"
print"<BODY>"

print"<h2>RPIalarm system web colntrol </h2>"

print"<FORM action='/cgi-bin/test.py' method='POST'>"

print"<INPUT TYPE='submit' NAME='option1' VALUE='Get latest data' style='height:30px;width:300px;font-size:16px;background-color:green;margin-top:1%'>"

print"</FORM>"
print"<p> %s </p>" %(time)
print"<h3 style='margin-top:3%'> Last images</h3>"

print"<div style='border:1px solid black;height:350px;width:1000px'>"

print"<img src=sorted/file1.jpg style='height:auto;width:15%;margin-top:5%;margin-left:3%;transform:rotate(90deg)'>"
print"<img src=sorted/file2.jpg style='height:auto;width:15%;transform:rotate(90deg)'>"
print"<img src=sorted/file3.jpg style='height:auto;width:15%;transform:rotate(90deg)'>"
print"<img src=sorted/file4.jpg style='height:auto;width:15%;transform:rotate(90deg)'>"
print"<img src=sorted/file5.jpg style='height:auto;width:15%;transform:rotate(90deg)'>"
print"<img src=sorted/file6.jpg style='height:auto;width:15%;transform:rotate(90deg)'>"

print"<img src=sorted/file7.jpg style='height:auto;width:15%;margin-top:8%;margin-left:3%;transform:rotate(90deg)'>"
print"<img src=sorted/file8.jpg style='height:auto;width:15%;transform:rotate(90deg)'>"
print"<img src=sorted/file9.jpg style='height:auto;width:15%;transform:rotate(90deg)'>"
print"<img src=sorted/file10.jpg style='height:auto;width:15%;transform:rotate(90deg)'>"
print"<img src=sorted/file11.jpg style='height:auto;width:15%;transform:rotate(90deg)'>"
print"<img src=sorted/file12.jpg style='height:auto;width:15%;transform:rotate(90deg)'>"

print"</div>"

print"<h3 style='margin-top:3%'> RPIalarm events</h3>"

print"<div style='border:1px solid black;height:535px;width:500px'>"

print"<p> %s </p>" % (log1)
print"<p> %s </p>" % (log2)
print"<p> %s </p>" % (log3)
print"<p> %s </p>" % (log4)
print"<p> %s </p>" % (log5)
print"<p> %s </p>" % (log6)
print"<p> %s </p>" % (log7)
print"<p> %s </p>" % (log8)
print"<p> %s </p>" % (log9)
print"<p> %s </p>" % (log10)
print"<p> %s </p>" % (log11)
print"<p> %s </p>" % (log12)
print"<p> %s </p>" % (log13)
print"<p> %s </p>" % (log14)
print"<p> %s </p>" % (log15)

print"</div>"

print"</BODY>"
print"</HTML>"


